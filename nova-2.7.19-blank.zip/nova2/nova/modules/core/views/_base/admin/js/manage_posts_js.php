<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}?>

<?php $string = random_string('alnum', 8);?>

<script type="text/javascript">
	$(document).ready(function(){

		// using the CI user agent library instead of jquery's $.browser since the latter is deprecated
		var browser = "<?php echo $this->agent->browser();?>";
		var version = parseFloat("<?php echo $this->agent->version();?>");

		// check to see if we should be using the Chosen plugin
		if (browser == 'Internet Explorer' && version < 8)
			$('#chosen-incompat').show();
		else
			$('.chosen').chosen();

		$('#tabs').tabs();
		$('#tabs').tabs('select', <?php echo $tab;?>);

		$('table.zebra tbody > tr:nth-child(odd)').addClass('alt');

		$("a[rel*=facebox]").click(function() {
			var page = $(this).attr('myPage');
			var status = $(this).attr('myStatus');
			var id = $(this).attr('myID');
			var action = $(this).attr('myAction');
			var location;

			if (action == 'approve')
				location = '<?php echo site_url('ajax/approve');?>/posts/' + id + '/<?php echo $string;?>';

			if (action == 'delete')
				location = '<?php echo site_url('ajax/del_post');?>/' + status + '/' + page + '/' + id + '/<?php echo $string;?>';

			$.facebox(function() {
				$.get(location, function(data) {
					$.facebox(data);
				});
			});

			return false;
		});

		const textArea = document.getElementById('content-textarea');
		const counter = document.getElementById('counter');

		counter.innerHTML = getWordCount(textArea.value);

		textArea.addEventListener('input', function () {
			let textLn = textArea.value;

			counter.innerHTML = getWordCount(textLn);
		});

		function getWordCount(str) {
			if (str === '') return 0;

			return str.trim().split(/\s+/).length;
		}
	});
</script>